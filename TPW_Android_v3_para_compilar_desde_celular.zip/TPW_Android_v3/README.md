# TPW Android v3 — flujo de taller (código fuente)

Proyecto Android nativo Kotlin + Jetpack Compose + Room/SQLite.

## Desarrollo agregado en v3
- Repositorio transaccional para crear una orden y guardar el dispositivo asociado.
- Consumo de repuesto: valida existencias, descuenta stock, registra el uso, agrega movimiento `REPAIR_USE` y actualiza el total de la orden dentro de una transacción Room.
- Entrada de stock con movimiento `IN`.
- Registro de pagos parciales que rechaza importes superiores al saldo.
- DAO para órdenes, dispositivos, pagos y movimientos.
- Utilidad existente para crear comprobante PDF e invocar impresión del sistema Android.
- Pruebas unitarias iniciales de cálculos básicos.

## Abrir
1. Extrae el ZIP.
2. Abre la carpeta en Android Studio.
3. Usa JDK 17 y Android SDK 35.
4. Sincroniza Gradle y ejecuta en un emulador o dispositivo.

## Estado honesto
No se ha verificado la compilación en este entorno. La interfaz principal de v2 no está aún conectada a todos los métodos nuevos del repositorio; este paquete añade la lógica de negocio y los DAO para integrarlos. No es todavía una app lista para producción.

## Limitaciones que faltan
- Conectar formularios de órdenes, inventario, consumo y pagos a la interfaz.
- Compartir PDF como adjunto requiere `FileProvider`; impresión es una función distinta.
- Los roles locales son demostrativos, no autenticación segura.
- La sincronización entre teléfonos y backend aún no está implementada.
- Añadir migraciones no destructivas, pruebas de integración, autenticación, control de acceso del servidor y respaldos probados antes de usar datos reales.

Los importes se almacenan en centavos enteros (`Long`) para evitar errores de coma flotante. El PDF es un comprobante interno, no una factura fiscal autorizada.

## Compilar APK desde un teléfono Android (GitHub Actions)

Este proyecto incluye `.github/workflows/build-apk.yml` para intentar compilar el APK en GitHub Actions. Esto no significa que el proyecto ya haya sido compilado o validado; la compilación debe comprobarse en GitHub.

1. Descarga el ZIP del proyecto y descomprímelo en el teléfono.
2. En el navegador, entra a https://github.com y crea una cuenta o inicia sesión.
3. Crea un repositorio nuevo, por ejemplo `TPW-Android`. Para mantener el código privado, selecciona **Private**.
4. Sube el contenido de la carpeta `TPW_Android_v3` al repositorio (no subas la carpeta contenedora como una carpeta adicional). Debe verse `app`, `build.gradle.kts`, `settings.gradle.kts` y `.github` en la raíz del repositorio.
5. Abre la pestaña **Actions**, habilita Actions si GitHub lo solicita y ejecuta **Build TPW APK** mediante **Run workflow**. También se ejecuta al subir cambios a `main`.
6. Si el trabajo termina en verde, abre esa ejecución, baja a **Artifacts** y descarga `TPW-debug-APK`. Descomprime el archivo descargado para obtener `app-debug.apk`.
7. Abre el APK en el teléfono y, si Android lo solicita, permite instalar aplicaciones desde ese navegador o administrador de archivos. Instala únicamente el APK que tú mismo compilaste en tu repositorio.

Si la compilación falla, abre el registro de la ejecución y comparte el texto del error para poder corregirlo. No compartas contraseñas ni tokens de GitHub.
