package com.tpw.taller.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val displayName: String,
    val username: String,
    val role: String, // ADMIN, RECEPCION, TECNICO
    val active: Boolean = true
)

@Entity(tableName = "clients")
data class ClientEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val name: String,
    val phone: String = "",
    val email: String = "",
    val address: String = "",
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val syncState: String = "PENDING"
)

@Entity(tableName = "devices")
data class DeviceEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val clientId: String,
    val brand: String = "",
    val model: String = "",
    val imei: String = "",
    val conditionOnArrival: String = "",
    val accessories: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val syncState: String = "PENDING"
)

@Entity(tableName = "repair_orders")
data class RepairOrderEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val orderNumber: String,
    val clientId: String,
    val deviceId: String,
    val reportedProblem: String,
    val diagnosis: String = "",
    val assignedTechnicianId: String = "",
    val status: String = "RECEIVED",
    val laborPriceCents: Long = 0,
    val partsCostCents: Long = 0,
    val totalPriceCents: Long = 0,
    val amountPaidCents: Long = 0,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val syncState: String = "PENDING"
)

@Entity(tableName = "parts")
data class PartEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val sku: String = "",
    val name: String,
    val category: String = "",
    val quantity: Int = 0,
    val minimumQuantity: Int = 1,
    val costCents: Long = 0,
    val salePriceCents: Long = 0,
    val supplier: String = "",
    val updatedAt: Long = System.currentTimeMillis(),
    val syncState: String = "PENDING"
)

@Entity(tableName = "inventory_movements")
data class InventoryMovementEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val partId: String,
    val repairOrderId: String = "",
    val movementType: String, // IN, OUT, REPAIR_USE, ADJUSTMENT
    val quantity: Int,
    val unitCostCents: Long,
    val note: String = "",
    val createdByUserId: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val syncState: String = "PENDING"
)

@Entity(tableName = "repair_part_usages")
data class RepairPartUsageEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val repairOrderId: String,
    val partId: String,
    val quantity: Int,
    val unitPriceCents: Long,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "payments")
data class PaymentEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val repairOrderId: String,
    val amountCents: Long,
    val method: String = "CASH",
    val note: String = "",
    val receivedByUserId: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val syncState: String = "PENDING"
)

@Entity(tableName = "cash_movements")
data class CashMovementEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val movementType: String,
    val amountCents: Long,
    val category: String = "",
    val description: String = "",
    val createdByUserId: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val syncState: String = "PENDING"
)
