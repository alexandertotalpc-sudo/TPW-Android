package com.tpw.taller.security

enum class UserRole { ADMIN, RECEPCION, TECNICO }
enum class AppAction { MANAGE_USERS, MANAGE_INVENTORY, REGISTER_CLIENT, CREATE_REPAIR,
    UPDATE_DIAGNOSIS, CHANGE_REPAIR_STATUS, REGISTER_PAYMENT, VIEW_CASH_REPORTS,
    EXPORT_RECEIPT, VIEW_ALL_REPORTS }

object LocalPermissions {
    fun can(role: UserRole, action: AppAction): Boolean = when (role) {
        UserRole.ADMIN -> true
        UserRole.RECEPCION -> action in setOf(
            AppAction.REGISTER_CLIENT, AppAction.CREATE_REPAIR,
            AppAction.CHANGE_REPAIR_STATUS, AppAction.REGISTER_PAYMENT,
            AppAction.EXPORT_RECEIPT
        )
        UserRole.TECNICO -> action in setOf(
            AppAction.UPDATE_DIAGNOSIS, AppAction.CHANGE_REPAIR_STATUS,
            AppAction.MANAGE_INVENTORY
        )
    }
}

/*
 * IMPORTANTE: estas reglas solo controlan la interfaz/lógica local. En una versión
 * multi-dispositivo el servidor debe autenticar al usuario y volver a comprobar permisos.
 */
