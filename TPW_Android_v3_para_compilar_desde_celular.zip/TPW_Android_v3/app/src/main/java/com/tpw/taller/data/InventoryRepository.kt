package com.tpw.taller.data

import androidx.room.withTransaction
import java.util.UUID

class InventoryRepository(private val db: TpwDatabase) {
    /**
     * Atomically decreases stock, records the usage, and records an inventory movement.
     * Throws IllegalArgumentException for invalid quantities or insufficient stock.
     */
    suspend fun consumeForRepair(
        partId: String,
        repairOrderId: String,
        quantity: Int,
        unitPriceCents: Long,
        userId: String
    ) {
        require(quantity > 0) { "La cantidad debe ser mayor que cero." }
        require(unitPriceCents >= 0) { "El precio no puede ser negativo." }

        db.withTransaction {
            val part = db.partDao().findById(partId)
                ?: throw IllegalArgumentException("No se encontró el repuesto.")
            require(part.quantity >= quantity) { "Existencias insuficientes: quedan ${part.quantity}." }

            db.partDao().update(
                part.copy(
                    quantity = part.quantity - quantity,
                    updatedAt = System.currentTimeMillis(),
                    syncState = "PENDING"
                )
            )
            db.repairPartUsageDao().insert(
                RepairPartUsageEntity(
                    id = UUID.randomUUID().toString(),
                    repairOrderId = repairOrderId,
                    partId = partId,
                    quantity = quantity,
                    unitPriceCents = unitPriceCents
                )
            )
            db.inventoryMovementDao().insert(
                InventoryMovementEntity(
                    partId = partId,
                    repairOrderId = repairOrderId,
                    movementType = "REPAIR_USE",
                    quantity = -quantity,
                    unitCostCents = part.costCents,
                    note = "Consumo en orden $repairOrderId",
                    createdByUserId = userId
                )
            )
        }
    }

    suspend fun addStock(partId: String, quantity: Int, userId: String, note: String = "") {
        require(quantity > 0) { "La cantidad debe ser mayor que cero." }
        db.withTransaction {
            val part = db.partDao().findById(partId)
                ?: throw IllegalArgumentException("No se encontró el repuesto.")
            db.partDao().update(part.copy(
                quantity = part.quantity + quantity,
                updatedAt = System.currentTimeMillis(),
                syncState = "PENDING"
            ))
            db.inventoryMovementDao().insert(InventoryMovementEntity(
                partId = partId,
                movementType = "IN",
                quantity = quantity,
                unitCostCents = part.costCents,
                note = note,
                createdByUserId = userId
            ))
        }
    }
}
