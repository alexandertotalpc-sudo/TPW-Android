package com.tpw.taller.receipts

import android.content.Context
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.print.PrintAttributes
import android.print.PrintManager
import android.os.Bundle
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class ReceiptData(
    val shopName: String = "TPW - Taller de reparación",
    val receiptNumber: String,
    val customerName: String,
    val deviceDescription: String,
    val workDescription: String,
    val totalCents: Long,
    val paidCents: Long,
    val currency: String = "USD"
) {
    val balanceCents: Long get() = (totalCents - paidCents).coerceAtLeast(0)
}

object ReceiptPdf {
    fun create(context: Context, data: ReceiptData): File {
        val document = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
        val page = document.startPage(pageInfo)
        val canvas = page.canvas
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 12f }
        var y = 56f

        fun line(text: String, bold: Boolean = false, size: Float = 12f) {
            paint.textSize = size
            paint.isFakeBoldText = bold
            canvas.drawText(text.take(88), 42f, y, paint)
            y += if (size >= 18f) 34f else 24f
        }
        fun money(cents: Long) = "$" + "%,.2f".format(Locale.US, cents / 100.0)

        line(data.shopName, true, 20f)
        line("COMPROBANTE DE SERVICIO", true, 14f)
        line("Comprobante: ${data.receiptNumber}")
        line("Fecha: ${SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date())}")
        y += 8f
        line("Cliente: ${data.customerName}", true)
        line("Equipo: ${data.deviceDescription}")
        line("Trabajo: ${data.workDescription}")
        y += 8f
        line("Total: ${money(data.totalCents)} ${data.currency}", true)
        line("Pagado: ${money(data.paidCents)} ${data.currency}")
        line("Saldo pendiente: ${money(data.balanceCents)} ${data.currency}", true)
        y += 18f
        line("Este documento es un comprobante interno de servicio.")
        line("No sustituye una factura fiscal autorizada.")
        document.finishPage(page)

        val dir = File(context.cacheDir, "receipts").apply { mkdirs() }
        val safeName = data.receiptNumber.replace(Regex("[^A-Za-z0-9_-]"), "_")
        val file = File(dir, "TPW_$safeName.pdf")
        FileOutputStream(file).use { document.writeTo(it) }
        document.close()
        return file
    }

    fun print(context: Context, pdf: File, jobName: String = "TPW comprobante") {
        val manager = context.getSystemService(Context.PRINT_SERVICE) as PrintManager
        manager.print(jobName, PdfFilePrintAdapter(pdf), PrintAttributes.Builder().build())
    }

    private class PdfFilePrintAdapter(private val file: File) : PrintDocumentAdapter() {
        override fun onLayout(
            oldAttributes: PrintAttributes?, newAttributes: PrintAttributes,
            cancellationSignal: CancellationSignal, callback: LayoutResultCallback, extras: Bundle?
        ) {
            if (cancellationSignal.isCanceled) {
                callback.onLayoutCancelled()
                return
            }
            callback.onLayoutFinished(
                PrintDocumentInfo.Builder(file.name)
                    .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                    .setPageCount(1).build(),
                true
            )
        }

        override fun onWrite(
            pages: Array<out android.print.PageRange>, destination: ParcelFileDescriptor,
            cancellationSignal: CancellationSignal, callback: WriteResultCallback
        ) {
            try {
                FileInputStreamCompat.copy(file, destination.fileDescriptor)
                callback.onWriteFinished(arrayOf(android.print.PageRange.ALL_PAGES))
            } catch (e: IOException) {
                callback.onWriteFailed(e.message)
            }
        }
    }

    private object FileInputStreamCompat {
        fun copy(file: File, destination: java.io.FileDescriptor) {
            file.inputStream().use { input ->
                FileOutputStream(destination).use { output -> input.copyTo(output) }
            }
        }
    }
}
