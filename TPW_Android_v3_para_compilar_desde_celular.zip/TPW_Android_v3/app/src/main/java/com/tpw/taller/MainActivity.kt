package com.tpw.taller

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import com.tpw.taller.data.*
import com.tpw.taller.security.*
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = TpwDatabase.getInstance(applicationContext)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = androidx.compose.ui.graphics.Color(0xFF38BDF8),
                secondary = androidx.compose.ui.graphics.Color(0xFF22C55E),
                background = androidx.compose.ui.graphics.Color(0xFF071426),
                surface = androidx.compose.ui.graphics.Color(0xFF10243B)
            )) { TpwApp(db) }
        }
    }
}

private enum class Section(val label: String, val icon: ImageVector) {
    Inicio("Inicio", Icons.Default.Dashboard),
    Clientes("Clientes", Icons.Default.People),
    Reparaciones("Órdenes", Icons.Default.Build),
    Inventario("Inventario", Icons.Default.Inventory2),
    Caja("Caja", Icons.Default.PointOfSale)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TpwApp(db: TpwDatabase) {
    var selected by remember { mutableStateOf(Section.Inicio) }
    var role by remember { mutableStateOf(UserRole.ADMIN) }
    var showNewClient by remember { mutableStateOf(false) }
    val clients by db.clientDao().observeAll().collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text("TPW • Taller") },
                actions = {
                    var expanded by remember { mutableStateOf(false) }
                    TextButton(onClick = { expanded = true }) { Text(role.name) }
                    DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                        UserRole.values().forEach { item ->
                            DropdownMenuItem(text = { Text(item.name) }, onClick = {
                                role = item
                                expanded = false
                            })
                        }
                    }
                }
            )
        },
        bottomBar = {
            NavigationBar {
                Section.values().forEach { section ->
                    NavigationBarItem(
                        selected = selected == section,
                        onClick = { selected = section },
                        icon = { Icon(section.icon, contentDescription = section.label) },
                        label = { Text(section.label) }
                    )
                }
            }
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            when (selected) {
                Section.Inicio -> {
                    Text("Panel de control", style = MaterialTheme.typography.headlineMedium)
                    Text("Gestión local • Moneda USD", style = MaterialTheme.typography.bodyLarge)
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        MetricCard("Clientes", clients.size.toString(), Icons.Default.People, Modifier.weight(1f))
                        MetricCard("Perfil", role.name, Icons.Default.Security, Modifier.weight(1f))
                    }
                    ModuleCard("Reparaciones", "Recepción, diagnóstico, estados y asignación.", Icons.Default.Build)
                    ModuleCard("Inventario", "El consumo de repuestos debe registrarse con movimiento.", Icons.Default.Inventory2)
                    ModuleCard("Comprobantes", "PDF digital e impresión del sistema Android.", Icons.Default.ReceiptLong)
                    Text("Nota: el selector de perfil es solo demostrativo; no es un inicio de sesión seguro.")
                }
                Section.Clientes -> {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Clientes", style = MaterialTheme.typography.headlineSmall)
                        Spacer(Modifier.weight(1f))
                        FilledTonalButton(
                            enabled = LocalPermissions.can(role, AppAction.REGISTER_CLIENT),
                            onClick = { showNewClient = true }
                        ) { Icon(Icons.Default.Add, contentDescription = null); Text(" Nuevo") }
                    }
                    if (clients.isEmpty()) {
                        EmptyState("Sin clientes todavía", "Pulsa Nuevo para registrar un cliente.")
                    } else {
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(clients, key = { it.id }) { client ->
                                Card(Modifier.fillMaxWidth()) {
                                    Column(Modifier.padding(14.dp)) {
                                        Text(client.name, style = MaterialTheme.typography.titleMedium)
                                        Text(client.phone.ifBlank { "Sin teléfono" })
                                        if (client.notes.isNotBlank()) Text(client.notes)
                                    }
                                }
                            }
                        }
                    }
                }
                Section.Reparaciones -> ModulePlaceholder(
                    "Órdenes de reparación",
                    "Siguiente integración: recepción del equipo, diagnóstico, técnico, estado, presupuesto y pagos.",
                    Icons.Default.Build
                )
                Section.Inventario -> ModulePlaceholder(
                    "Inventario de repuestos",
                    "El repositorio InventoryRepository incluye consumo transaccional con descuento de stock y movimiento de auditoría.",
                    Icons.Default.Inventory2
                )
                Section.Caja -> ModulePlaceholder(
                    "Caja y pagos",
                    "Siguiente integración: abonos, saldos, ingresos/gastos y reportes.",
                    Icons.Default.PointOfSale
                )
            }
        }
    }

    if (showNewClient) {
        NewClientDialog(
            onDismiss = { showNewClient = false },
            onSave = { name, phone, notes ->
                scope.launch { db.clientDao().insert(ClientEntity(name = name, phone = phone, notes = notes)) }
                showNewClient = false
            }
        )
    }
}

@Composable
private fun MetricCard(title: String, value: String, icon: ImageVector, modifier: Modifier = Modifier) {
    Card(modifier) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Text(title)
            Text(value, style = MaterialTheme.typography.titleLarge)
        }
    }
}

@Composable
private fun ModuleCard(title: String, subtitle: String, icon: ImageVector) {
    Card(Modifier.fillMaxWidth()) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.width(12.dp))
            Column {
                Text(title, style = MaterialTheme.typography.titleMedium)
                Text(subtitle, style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}

@Composable
private fun ModulePlaceholder(title: String, description: String, icon: ImageVector) {
    Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
    Text(title, style = MaterialTheme.typography.headlineSmall)
    Text(description, style = MaterialTheme.typography.bodyLarge)
    EmptyState("Base preparada", "La pantalla todavía requiere formularios completos y pruebas de flujo.")
}

@Composable
private fun EmptyState(title: String, message: String) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Text(message, style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@Composable
private fun NewClientDialog(onDismiss: () -> Unit, onSave: (String, String, String) -> Unit) {
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Nuevo cliente") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Nombre completo *") }, singleLine = true)
                OutlinedTextField(phone, { phone = it }, label = { Text("Teléfono") }, singleLine = true)
                OutlinedTextField(notes, { notes = it }, label = { Text("Notas") })
            }
        },
        confirmButton = {
            Button(onClick = { if (name.isNotBlank()) onSave(name.trim(), phone.trim(), notes.trim()) }, enabled = name.isNotBlank()) {
                Text("Guardar")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}
