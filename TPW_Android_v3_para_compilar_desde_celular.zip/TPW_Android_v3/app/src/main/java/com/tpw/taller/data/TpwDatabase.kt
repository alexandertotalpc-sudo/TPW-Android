package com.tpw.taller.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ClientDao {
    @Query("SELECT * FROM clients ORDER BY name COLLATE NOCASE")
    fun observeAll(): Flow<List<ClientEntity>>
    @Query("SELECT * FROM clients WHERE id = :id LIMIT 1")
    suspend fun findById(id: String): ClientEntity?
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(client: ClientEntity)
}

@Dao
interface DeviceDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(device: DeviceEntity)
}

@Dao
interface RepairOrderDao {
    @Query("SELECT * FROM repair_orders ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<RepairOrderEntity>>

    @Query("SELECT * FROM repair_orders WHERE id = :id LIMIT 1")
    suspend fun findById(id: String): RepairOrderEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(order: RepairOrderEntity)

    @Update
    suspend fun update(order: RepairOrderEntity)
}

@Dao
interface PaymentDao {
    @Query("SELECT * FROM payments WHERE repairOrderId = :orderId ORDER BY createdAt DESC")
    suspend fun byOrder(orderId: String): List<PaymentEntity>

    @Insert
    suspend fun insert(payment: PaymentEntity)
}

@Dao
interface PartDao {
    @Query("SELECT * FROM parts ORDER BY name COLLATE NOCASE")
    fun observeAll(): Flow<List<PartEntity>>

    @Query("SELECT * FROM parts WHERE id = :id LIMIT 1")
    suspend fun findById(id: String): PartEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(part: PartEntity)

    @Update
    suspend fun update(part: PartEntity)
}

@Dao
interface InventoryMovementDao {
    @Insert
    suspend fun insert(movement: InventoryMovementEntity)

    @Query("SELECT * FROM inventory_movements ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<InventoryMovementEntity>>

    @Query("SELECT * FROM inventory_movements ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<InventoryMovementEntity>>
}

@Dao
interface RepairPartUsageDao {
    @Insert
    suspend fun insert(usage: RepairPartUsageEntity)

    @Query("SELECT * FROM repair_part_usages WHERE repairOrderId = :orderId ORDER BY createdAt DESC")
    suspend fun byOrder(orderId: String): List<RepairPartUsageEntity>
}

@Database(
    entities = [
        UserEntity::class, ClientEntity::class, DeviceEntity::class,
        RepairOrderEntity::class, PartEntity::class, InventoryMovementEntity::class,
        RepairPartUsageEntity::class, PaymentEntity::class, CashMovementEntity::class
    ],
    version = 2,
    exportSchema = false
)
abstract class TpwDatabase : RoomDatabase() {
    abstract fun clientDao(): ClientDao
    abstract fun repairOrderDao(): RepairOrderDao
    abstract fun deviceDao(): DeviceDao
    abstract fun paymentDao(): PaymentDao
    abstract fun partDao(): PartDao
    abstract fun inventoryMovementDao(): InventoryMovementDao
    abstract fun repairPartUsageDao(): RepairPartUsageDao

    companion object {
        @Volatile private var INSTANCE: TpwDatabase? = null
        fun getInstance(context: Context): TpwDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext, TpwDatabase::class.java, "tpw_local.db"
                ).fallbackToDestructiveMigration()
                 .build().also { INSTANCE = it }
            }
    }
}
