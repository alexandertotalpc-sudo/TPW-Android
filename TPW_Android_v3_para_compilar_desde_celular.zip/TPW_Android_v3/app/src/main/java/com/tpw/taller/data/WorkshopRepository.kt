package com.tpw.taller.data

import androidx.room.withTransaction
import java.util.UUID

/** Operaciones críticas de taller ejecutadas como transacciones SQLite. */
class WorkshopRepository(private val db: TpwDatabase) {
    suspend fun createOrder(
        client: ClientEntity,
        brand: String,
        model: String,
        imei: String,
        problem: String,
        diagnosis: String,
        technicianId: String,
        laborPriceCents: Long
    ): RepairOrderEntity = db.withTransaction {
        require(problem.isNotBlank()) { "El problema reportado es obligatorio." }
        require(laborPriceCents >= 0) { "El precio no puede ser negativo." }
        val savedClient = db.clientDao().let { dao ->
            // Revalidamos el cliente en la base antes de asociar la orden.
            // La consulta se implementa en ClientDao para evitar usar datos obsoletos.
            dao.findById(client.id) ?: throw IllegalArgumentException("El cliente ya no existe.")
        }
        val id = UUID.randomUUID().toString()
        val number = "TPW-${System.currentTimeMillis().toString().takeLast(8)}"
        val deviceId = UUID.randomUUID().toString()
        db.deviceDao().insert(DeviceEntity(
            id = deviceId, clientId = savedClient.id, brand = brand.trim(),
            model = model.trim(), imei = imei.trim(), conditionOnArrival = problem.trim()
        ))
        val order = RepairOrderEntity(
            id = id,
            orderNumber = number,
            clientId = savedClient.id,
            deviceId = deviceId,
            reportedProblem = problem.trim(),
            diagnosis = diagnosis.trim(),
            assignedTechnicianId = technicianId.trim(),
            status = "RECEIVED",
            laborPriceCents = laborPriceCents,
            totalPriceCents = laborPriceCents
        )
        db.repairOrderDao().insert(order)
        order
    }

    /** Descuenta stock, añade línea de repuesto y movimiento, y recalcula total en una sola transacción. */
    suspend fun consumePart(orderId: String, partId: String, quantity: Int, userId: String) = db.withTransaction {
        require(quantity > 0) { "La cantidad debe ser mayor que cero." }
        val order = db.repairOrderDao().findById(orderId)
            ?: throw IllegalArgumentException("La orden no existe.")
        val part = db.partDao().findById(partId)
            ?: throw IllegalArgumentException("El repuesto no existe.")
        require(part.quantity >= quantity) { "Stock insuficiente: disponibles ${part.quantity}." }
        val lineTotal = Math.multiplyExact(part.salePriceCents, quantity.toLong())
        val updatedTotal = Math.addExact(order.totalPriceCents, lineTotal)

        db.partDao().update(part.copy(
            quantity = part.quantity - quantity,
            updatedAt = System.currentTimeMillis(),
            syncState = "PENDING"
        ))
        db.repairPartUsageDao().insert(RepairPartUsageEntity(
            repairOrderId = orderId,
            partId = partId,
            quantity = quantity,
            unitPriceCents = part.salePriceCents
        ))
        db.inventoryMovementDao().insert(InventoryMovementEntity(
            partId = partId,
            repairOrderId = orderId,
            movementType = "REPAIR_USE",
            quantity = -quantity,
            unitCostCents = part.costCents,
            note = "Repuesto utilizado en reparación ${order.orderNumber}",
            createdByUserId = userId
        ))
        db.repairOrderDao().update(order.copy(
            totalPriceCents = updatedTotal,
            updatedAt = System.currentTimeMillis(),
            syncState = "PENDING"
        ))
    }

    suspend fun addStock(partId: String, quantity: Int, userId: String, note: String = "Reposición") = db.withTransaction {
        require(quantity > 0) { "La cantidad debe ser mayor que cero." }
        val part = db.partDao().findById(partId) ?: throw IllegalArgumentException("El repuesto no existe.")
        val updatedQty = Math.addExact(part.quantity, quantity)
        db.partDao().update(part.copy(quantity = updatedQty, updatedAt = System.currentTimeMillis(), syncState = "PENDING"))
        db.inventoryMovementDao().insert(InventoryMovementEntity(
            partId = partId, movementType = "IN", quantity = quantity,
            unitCostCents = part.costCents, note = note, createdByUserId = userId
        ))
    }

    suspend fun registerPayment(orderId: String, amountCents: Long, method: String, userId: String) = db.withTransaction {
        require(amountCents > 0) { "El abono debe ser mayor que cero." }
        val order = db.repairOrderDao().findById(orderId) ?: throw IllegalArgumentException("La orden no existe.")
        require(amountCents <= order.totalPriceCents - order.amountPaidCents) { "El abono supera el saldo pendiente." }
        db.paymentDao().insert(PaymentEntity(
            repairOrderId = orderId, amountCents = amountCents,
            method = method, receivedByUserId = userId
        ))
        db.repairOrderDao().update(order.copy(
            amountPaidCents = Math.addExact(order.amountPaidCents, amountCents),
            updatedAt = System.currentTimeMillis(), syncState = "PENDING"
        ))
    }
}
