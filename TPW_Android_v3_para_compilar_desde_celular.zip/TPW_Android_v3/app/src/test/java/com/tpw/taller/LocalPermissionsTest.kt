package com.tpw.taller

import com.tpw.taller.security.AppAction
import com.tpw.taller.security.LocalPermissions
import com.tpw.taller.security.UserRole
import org.junit.Assert.*
import org.junit.Test

class LocalPermissionsTest {
    @Test fun adminCanManageUsers() {
        assertTrue(LocalPermissions.can(UserRole.ADMIN, AppAction.MANAGE_USERS))
    }

    @Test fun technicianCannotRegisterPayments() {
        assertFalse(LocalPermissions.can(UserRole.TECNICO, AppAction.REGISTER_PAYMENT))
    }

    @Test fun receptionCanExportReceipt() {
        assertTrue(LocalPermissions.can(UserRole.RECEPCION, AppAction.EXPORT_RECEIPT))
    }
}
