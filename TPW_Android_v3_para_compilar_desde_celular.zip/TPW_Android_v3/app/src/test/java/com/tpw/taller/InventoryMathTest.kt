package com.tpw.taller

import org.junit.Assert.*
import org.junit.Test

class InventoryMathTest {
    @Test fun stockConsumptionShouldNotGoNegative() {
        val stock = 4
        val used = 3
        assertTrue(used > 0 && stock >= used)
        assertEquals(1, stock - used)
        assertFalse(stock >= 5)
    }

    @Test fun moneyUsesIntegerCents() {
        assertEquals(1250L, "12.50".toBigDecimal().movePointRight(2).longValueExact())
    }
}
